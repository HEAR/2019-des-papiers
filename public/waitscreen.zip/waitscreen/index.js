var can, dd, img, main, noto, toggle, t, timer, timer2, counter;
var oldnum, maxsvgs, maximgs;
var svgcounter, mySound, audio;

function preload() {
  noto = loadFont('typo/NotoSans-CondensedBlack.ttf');
	// soundFormats('mp3', 'ogg', 'wav');
 //  mySound = loadSound('sounds/sound4 beepbox.mp3');

  audio = new Audio('sounds/sound4beepbox2.mp3');
  audio.addEventListener('ended', function(){
  	this.currentTime = 0;
  	this.pause();
  },false)
}


function setup() {
	toggle 					= true;
	t 							= "";
	counter 				= 0;
	oldnum 					= 0;
	svgcounter 			= 0;
	maxsvgs 				= 100;
	maximgs 				= 60;
	//callJson();		
}

function callJson() {
	loadJSON("http://169.254.155.152:3000/get_id", "json", getter); 
	// loadJSON("./tester.json?cache="+new Date(), "json", getter);  
}

// $("#counter").mousedown(function() {
//   // callJson()
//   alert("hhhhhhh")
// });


function getter(obj) {
	if (oldnum !== obj.id) {

		svgcounter++;
		if (svgcounter > maxsvgs) {
			svgcounter = 0;
		}

		console.log("logo url", obj.logo);

		$("#counter p").text(obj.id);
		$("#mysvg").load(obj.logo);
		//$("#myimg").load("svgs/test" + svgcounter + ".svg");
		//$('#myimg').attr('src', "logo-captures/logo" + svgcounter + ".png");

		t 				= obj.id;				// used in blink
		counter 	= 0;						// used to clear timer
		toggle 		= true;					// used in blinker

		timer = setInterval(blink, 500);
		audio.play()
	}

	oldnum = obj.id;
}

function blink() {
	toggle = !toggle;
	counter++;

	background(0);

	if (toggle) {
		$("#counter p").show();
	} else {
		$("#counter p").hide();
	}

	if (counter > 5) {
		clearInterval(timer);
	}
}

function switcher() {
	  // can = null;
	  // can = createCanvas(windowWidth/2, windowHeight);  // 1920, 1200
	  // can.id('can');
	  // can.style('float', 'left');

  // $('#can').css({
	 //  width: $(window).width()/2,
	 //  height: $(window).height()
	 // });

 	// $('#mydiv').css({
	 //  width: $(window).width()/2,
	 //  height: $(window).height()
	 // });
}

$(window).resize(function() {
    switcher();         
});

// function mousePressed() {
// 	// let fsc = fullscreen();
//  //    fullscreen(!fsc);
// }

timer2 = setInterval(callJson, 4000);
